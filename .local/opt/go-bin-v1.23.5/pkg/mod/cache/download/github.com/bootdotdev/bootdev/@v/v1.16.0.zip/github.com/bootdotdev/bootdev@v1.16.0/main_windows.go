//go:build windows

package main

func main() {
	windows_is_not_supported_please_use_WSL()
}
